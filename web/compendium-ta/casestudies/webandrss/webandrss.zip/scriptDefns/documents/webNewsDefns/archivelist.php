<?php

function displayFile($filename){

	$outputFromPHP = fopen($filename,'r');
	while ($line = fgets($outputFromPHP, 1024)){
		print($line);
	}
	fclose($outputFromPHP);
}

?>

<html>
  <head>

	<title>News Archive List</title>

  </head>
  <body>

<h1>News Archive List</h1>

<p>&nbsp;</p>


<?php

		// import archive details
		displayFile("./dat/archivelist.dat");
?>

	<p>&nbsp;</p>

 </div>
	<?php print("Generated ".date("l, F dS Y."));	?>
</body>
</html>
