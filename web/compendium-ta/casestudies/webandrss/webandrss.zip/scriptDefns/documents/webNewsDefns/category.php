<?php

function displayFile($filename){

	if (file_exists($filename)){
	     $outputFromPHP = fopen($filename,'r');
		while ($line = fgets($outputFromPHP, 1024)){
			print($line);
		}
		fclose($outputFromPHP);
	}

}

?>

<html>
  <head>

<?php


	if(!isset($catid)){
	     if (array_key_exists("catid", $_GET)){
			$catid = $_GET["catid"];
		}else{
		$catid = "";
		}
	}

	if(!isset($pageid)){
	     if (array_key_exists("pageid", $_GET)){
			$pageid= $_GET["pageid"];
		}else{
		$pageid= "1";
		}
	}
?>

	<?php print("<title>".$catid." News Archive</title>"); ?>

  </head>
  <body>

  <?php	print("<h1>$catid." News Archive</h1>"); ?>

<p>&nbsp;</p>


<p><a href="archivelist.php">Archive List</a> : <a href="category.php?catid=<?php print($catid) ?>"><?php print($catid) ?></a> </p>

<?php

		// import archive details
		displayFile("./dat/".$catid.$pageid.".dat");
?>

	<p>&nbsp;</p>

 </div>
	<?php print("Generated ".date("l, F dS Y."));	?>
</body>
</html>
